from ninja.compatibility.request import get_headers

__all__ = ["get_headers"]
